<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
    <head>
      <title>Tentang Kami</title>
          <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="hotel.jpeg" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Hotel SMKN 6 JAMBI</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-siswa.php">Data Reservasi</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="tentang-kami.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>

      
          </ul>
          <div class="konten">
            <h2>Apa Itu Hotel Digital (E – Hotel)? </h2>
            <p>Hotel digital (digital Hotel atau E – Hotel) adalah tempat di mana Anda dapat menyusun data secara digital atau daring.
              Di era digital seperti sekarang ini, hotel digital cukup penting untuk dimiliki karena dapat memudahkan prnyusunan data-data.
              Tentunya, hotel digital punya beberapa keunggulan dan kelemahannya. Berikut informasinya.</p>
              
              <h2>Keunggulan Digital Hotel </h2>
              <p>Tentu saja, segala sesuatu yang bersifat digital memudahkan manusia. Hal ini juga berlaku untuk hotel digital. Berikut adalah keunggulan E-Hotel ini:</p>
              <p>1. Praktis dan tidak terbatas oleh waktu dan tempat.</p>
              <p>2. Tidak memerlukan tempat penyimpanan fisik.</p>
              <p>3. Mudah digunakan oleh siapa saja karena menggunakan teknologi digital.</p>
            </div>
          <div class="fotter">
          <p>Hak Cipta 2025 © Pengembangan Perangkat Lunak dan Gim</p>
          </div>
    </body>
</html>