<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$data=queryBuku("select*from data");
if(isset($_POST["tombol"])){
    $pencarian= $_POST ["pencarian"];
   $dicari="SELECT *FROM data WHERE
    nama like '%$pencarian%' or
    hobi like '%$pencarian%' or
    gender like '%$pencarian%' or
    alamat like '%$pencarian%' or
    nomor like '%$pencarian%' or
    skill like '%$pencarian%'";
    $data=mysqli_query($database,$dicari);

} else{
    $data=queryBuku("select*from data");
}

?>
<!doctype html>
<html>
<head>
<title>
Portfolio

</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="data-siswa.php"> SMKN 6 JAMBI</a>
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="data-siswa.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah-siswa.php">Tambah Data</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
      
          </ul>
          <div class="konten">

    <h1> Portfolio </h1>
  
    <form action="" method="post">
        <input type="text" name="pencarian">
        <button type="submit" name="tombol">Cari</button>
    </form>
    <table border="1" cellpadding="10" cellspacing="0">
    <tr class="table-header">

        <th>No</th>
        <th>Nama</th>
        <th>Hobi</th>
        <th>Gender</th>
        <th>Alamat</th>
        <th>No Telepon</th>
        <th>Skill</th>
        <th>Pendidikan</th>
        <th>Pekerjaan</th>
        <th>Keperibadian</th>
        <th>Aksi</th>
       
        </tr>

        <?php
        $aku=1;
        ?>
    

        
        <?php
foreach ($data as $cari):

        ?>
        <tr><td class="table-header1"><?php echo $aku; ?></td>
        <td class="table-header2"><?php echo $cari["nama"] ?></td>
        <td class="table-header3"><?php echo $cari["hobi"] ?></td>
        <td class="table-header3"><?php echo $cari["gender"] ?></td>
        <td class="table-header4"><?php echo $cari["alamat"] ?></td>
        <td class="table-header5"><?php echo $cari["nomor"] ?></td>
        <td class="table-header6"><?php echo $cari["skill"]?></td>
        <td class="table-header5"><?php echo $cari["pendidikan"] ?></td>
        <td class="table-header5"><?php echo $cari["pekerjaan"] ?></td>
        <td class="table-header5"><?php echo $cari["kepribadian"] ?></td>

    
        <td class="table-header9"><a href="edit-siswa.php?no=<?php echo $cari["no"] ?>">Edit</a> |
            <a href="hapus-siswa.php?no=<?php echo $cari["no"] ?>">Hapus</a></td>
        </tr>

        <?php
        $aku++;
        ?>

        <?php
        endforeach;
        ?>


    </table>
    </body>
    </html>