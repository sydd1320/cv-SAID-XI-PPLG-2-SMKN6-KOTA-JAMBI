<?php
$database= mysqli_connect("localhost","root","","cv");

function queryBuku ($queryBuku){
    global $database;
  $tampilkan = mysqli_query($database, $queryBuku);
  $wadahkosong = [];
  while( $data =mysqli_fetch_assoc($tampilkan)){
    $wadahkosong [] =$data;
  }
  return $wadahkosong;
}


function tambahSiswa($tambahSiswa){
    global $database;
    $nama=$_POST["nama"];
    $kelas=$_POST["hobi"];
    $gender=$_POST["gender"];
    $jurusan=$_POST["alamat"];
    $alamat=$_POST["nomor"];
    $rt=$_POST["skill"];
    $jawa=$_POST["pendidikan"];
    $sunda=$_POST["pekerjaan"];
    $jambi=$_POST["kepribadian"];
    $tambah_biodata="insert into data values
    ('','$nama','$kelas','$gender','$jurusan','$alamat','$rt','$jawa','$sunda','$jambi')"; 
    mysqli_query($database,$tambah_biodata);
    return mysqli_affected_rows($database);
}
function hapusSiswa($hapusSiswa){
    global $database;
    mysqli_query($database,"delete from data where no=$hapusSiswa");
    return mysqli_affected_rows($database);
}
function editSiswa($editSiswa){
    global $database;
    $hapus=$_GET["no"];
    $nis=$_POST["no"];
    $nama=$_POST["nama"];
    $kelas=$_POST["hobi"];
    $gender=$_POST["gender"];
    $jurusan=$_POST["alamat"];
    $jenis_kelamin=$_POST["nomor"];
    $alamat=$_POST["skill"];
    $jawa=$_POST["pendidikan"];
    $sunda=$_POST["pekerjaan"];
    $jambi=$_POST["kepribadian"];




    $edit = "update data set  

    nama = '$nama',
    hobi = '$kelas',
    gender = '$gender',
    alamat = '$jurusan',
    nomor = '$jenis_kelamin',
    skill = '$alamat',
    pendidikan = '$jawa',
    pekerjaan = '$sunda',
    kepribadian = '$jambi'


    where no =$hapus"; 
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);
}
function tambahadmin ($tambahadmin){
    global $database;
    $no=$_POST["no"];
    $nip=$_POST["username"];
    $nama_petugas=$_POST["password"];
    
    $tambah_data="insert into login value
    ('','$nip','$nama_petugas')";
    mysqli_query($database,$tambah_data);
    return mysqli_affected_rows($database);
}
function hapusadmin ($hapusadmin){
    global $database;
    mysqli_query($database,"delete from login where no=$hapusadmin");
    return mysqli_affected_rows($database);
}
function editadmin ($editadmin){
    global $database;
    $hapus=$_GET["no"];
    $no=$_POST["no"];
    $nip=$_POST["username"];
    $nama_petugas=$_POST["password"];
    $edit="update login set
    no = '$no',
    username = '$nip',
    password = '$nama_petugas'
    where no=$hapus";
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);


}

?>