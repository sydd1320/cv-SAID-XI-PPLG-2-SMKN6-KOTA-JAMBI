<?php

require 'function.php';
$data=queryBuku("select*from data");
if(isset($_POST["tombol"])){
    $pencarian= $_POST ["pencarian"];
   $dicari="SELECT *FROM data WHERE
    kamar like '%$pencarian%' or
    nama like '%$pencarian%' or
    nohp like '%$pencarian%' or
    tipe like '%$pencarian%' or
    harga like '%$pencarian%' or
    checkin like '%$pencarian%' or
    checkout like '%$pencarian%'";
    $data=mysqli_query($database,$dicari);

} else{
    $data=queryBuku("select*from data");
}

?>
<!doctype html>
<html>
<head>
<title>
CV Sydd

</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="data-siswa.php"> SMKN 6 JAMBI</a>
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="data-siswa.php">Beranda</a></li>
        
      
          </ul>
          <div class="konten">

    <h1> Portfolio </h1>
  
    <form action="" method="post">
        <input type="text" name="pencarian">
        <button type="submit" name="tombol">Cari</button>
    </form>
    <table border="1" cellpadding="10" cellspacing="0">
    <tr class="table-header">

        <th>No</th>
        <th>Nama</th>
        <th>Jenis Kelamin</th>
        <th>Alamat</th>
        <th>No Telepon</th>
        <th>Skill</th>
       
        </tr>

        <?php
        $aku=1;
        ?>
    

        
        <?php
foreach ($data as $cari):

        ?>
        <tr><td class="table-header1"><?php echo $aku; ?></td>
        <td class="table-header2"><?php echo $cari["nama"] ?></td>
        <td class="table-header3"><?php echo $cari["gender"] ?></td>
        <td class="table-header4"><?php echo $cari["alamat"] ?></td>
        <td class="table-header5"><?php echo $cari["nomor"] ?></td>
        <td class="table-header6"><?php echo $cari["skill"]?></td>
    
     
        </tr>

        <?php
        $aku++;
        ?>

        <?php
        endforeach;
        ?>

    </table>
    </body>
    </html>