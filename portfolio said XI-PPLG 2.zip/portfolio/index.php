<?php
require 'function.php';
$data=queryBuku("select*from data");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Shido</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="container">
        <div class="header">
            <div class="gambar">  <img src="mc.jfif" alt="trailblaze">

            </div>
            <?php
            foreach ($data as $cari):
            ?>
            <h1><?= $cari ['nama']?></h1>
            <h3><?= $cari ['gender']?></h3>
            <?php
        endforeach;
        ?>


        </div>
        <div class="main">
            <div class="left">
                <h2>Informasi Identitas</h2>
                <p><strong>Nama</strong> <?= $cari ['nama']?></p>
                <p><strong>Hobi</strong> <?= $cari ['hobi']?></p>
                <p><strong>Alamat</strong> <?= $cari ['alamat']?></p>
                <p><strong>No. Telepon</strong> <?= $cari ['nomor']?></p>
                <p><strong>Skill</strong> <?= $cari ['skill']?></p>
                <h2>Pendidikan</h2>
                <p><?= $cari ['pendidikan']?></p>
            </div>
            <div class="right">
                <h2>Pekerjaan</h2>
                <p><?= $cari ['pekerjaan']?></p>
                <h2>Kepribadian</h2>
                <li><?= $cari ['kepribadian']?></li>
                



            </div>
        </div>
    </div>
</body>
</html>